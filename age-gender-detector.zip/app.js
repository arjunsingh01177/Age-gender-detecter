class AgeGenderDetection {
    constructor() {
        this.video = document.getElementById('video');
        this.canvas = document.getElementById('overlay');
        this.ctx = this.canvas.getContext('2d');
        this.startBtn = document.getElementById('startBtn');
        this.stopBtn = document.getElementById('stopBtn');
        this.statusEl = document.getElementById('status');
        this.fpsEl = document.getElementById('fps');
        this.resultsEl = document.getElementById('results');
        this.errorModal = document.getElementById('errorModal');
        this.loadingModal = document.getElementById('loadingModal');
        this.loadingStatus = document.getElementById('loadingStatus');
        this.progressFill = document.getElementById('progressFill');
        
        this.isDetecting = false;
        this.detectionLoop = null;
        this.lastTime = 0;
        this.frameCount = 0;
        this.fps = 0;
        this.modelsLoaded = false;
        
        // Detection settings
        this.detectionOptions = new faceapi.TinyFaceDetectorOptions({
            inputSize: 224,
            scoreThreshold: 0.5
        });
        
        // Use reliable model URLs - different CDN
        this.modelUrls = '/models';
        
        this.init();
    }
    
    init() {
        this.startBtn.addEventListener('click', () => this.startDetection());
        this.stopBtn.addEventListener('click', () => this.stopDetection());
        document.getElementById('closeError').addEventListener('click', () => this.hideModal(this.errorModal));
        
        // Update status
        this.updateStatus('Ready to start', 'info');
        console.log('Face-api version:', faceapi.version || 'unknown');
    }
    
    async startDetection() {
        try {
            this.showLoadingState();
            
            // Load models first
            if (!this.modelsLoaded) {
                await this.loadModels();
                this.modelsLoaded = true;
            }
            
            // Then start camera
            await this.startCamera();
            
            // Wait a moment for video to be ready
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            this.startDetectionLoop();
            this.showDetectingState();
            
        } catch (error) {
            console.error('Error starting detection:', error);
            this.showError(this.getErrorMessage(error));
            this.hideLoadingState();
        }
    }
    
    async loadModels() {
        try {
            // Try multiple model URLs in order of preference
            const modelUrls = [
                'https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights',
                'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/model',
                'https://unpkg.com/face-api.js@0.22.2/weights'
            ];
            
            let modelsLoadedSuccessfully = false;
            
            for (let i = 0; i < modelUrls.length; i++) {
                try {
                    const modelUrl = modelUrls[i];
                    console.log(`Attempting to load models from: ${modelUrl}`);
                    
                    this.updateLoadingStatus(`Loading face detection model... (${i + 1}/${modelUrls.length})`, 20);
                    await faceapi.nets.tinyFaceDetector.loadFromUri(modelUrl);
                    
                    this.updateLoadingStatus('Loading facial landmarks model...', 50);
                    await faceapi.nets.faceLandmark68TinyNet.loadFromUri(modelUrl);
                    
                    this.updateLoadingStatus('Loading age and gender model...', 80);
                    await faceapi.nets.ageGenderNet.loadFromUri(modelUrl);
                    
                    this.updateLoadingStatus('Models loaded successfully!', 100);
                    modelsLoadedSuccessfully = true;
                    console.log(`Models loaded successfully from: ${modelUrl}`);
                    break;
                    
                } catch (urlError) {
                    console.warn(`Failed to load from ${modelUrls[i]}:`, urlError);
                    if (i === modelUrls.length - 1) {
                        throw urlError;
                    }
                    continue;
                }
            }
            
            if (!modelsLoadedSuccessfully) {
                throw new Error('Failed to load models from all available sources');
            }
            
            // Wait a moment to show completion
            await new Promise(resolve => setTimeout(resolve, 500));
            
        } catch (error) {
            console.error('Model loading error:', error);
            throw new Error('Failed to load AI models. This might be due to network connectivity or CORS issues. Please refresh the page and try again.');
        }
    }
    
    async startCamera() {
        try {
            this.updateLoadingStatus('Requesting camera access...', 90);
            
            // Check for getUserMedia support
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('Camera access is not supported in this browser. Please use Chrome, Firefox, or Safari.');
            }
            
            console.log('Requesting camera access...');
            
            const constraints = {
                video: {
                    width: { ideal: 640, max: 1280 },
                    height: { ideal: 480, max: 720 },
                    facingMode: 'user'
                },
                audio: false
            };
            
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            console.log('Camera access granted, stream:', stream);
            
            this.video.srcObject = stream;
            
            return new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    reject(new Error('Video loading timeout. Please try again.'));
                }, 10000);
                
                this.video.onloadedmetadata = () => {
                    console.log('Video metadata loaded');
                    clearTimeout(timeout);
                    
                    this.video.play()
                        .then(() => {
                            console.log('Video playing, dimensions:', this.video.videoWidth, 'x', this.video.videoHeight);
                            
                            // Set canvas size to match video
                            this.canvas.width = this.video.videoWidth || 640;
                            this.canvas.height = this.video.videoHeight || 480;
                            
                            this.updateLoadingStatus('Camera ready!', 100);
                            this.hideLoadingState();
                            resolve();
                        })
                        .catch((playError) => {
                            console.error('Video play error:', playError);
                            clearTimeout(timeout);
                            reject(new Error('Failed to start video playback. Please try again.'));
                        });
                };
                
                this.video.onerror = (error) => {
                    console.error('Video error:', error);
                    clearTimeout(timeout);
                    reject(new Error('Video error occurred'));
                };
                
                // Fallback: if metadata doesn't load, try to play anyway
                setTimeout(() => {
                    if (this.video.readyState === 0) {
                        console.log('Metadata loading slowly, trying to play anyway...');
                        this.video.play().catch(console.error);
                    }
                }, 3000);
            });
            
        } catch (error) {
            console.error('Camera access error:', error);
            
            if (error.name === 'NotAllowedError') {
                throw new Error('Camera permission denied. Please allow camera access and refresh the page.');
            } else if (error.name === 'NotFoundError') {
                throw new Error('No camera found. Please ensure your device has a camera.');
            } else if (error.name === 'NotReadableError') {
                throw new Error('Camera is already in use by another application.');
            } else if (error.name === 'OverconstrainedError') {
                throw new Error('Camera does not support the required settings.');
            } else {
                throw new Error(error.message || 'Failed to access camera. Please check your browser settings and try again.');
            }
        }
    }
    
    startDetectionLoop() {
        this.isDetecting = true;
        this.lastTime = performance.now();
        this.frameCount = 0;
        
        console.log('Starting detection loop...');
        
        const detect = async () => {
            if (!this.isDetecting || this.video.readyState !== 4) {
                if (this.isDetecting) {
                    requestAnimationFrame(detect);
                }
                return;
            }
            
            try {
                // Calculate FPS
                const currentTime = performance.now();
                this.frameCount++;
                if (currentTime - this.lastTime >= 1000) {
                    this.fps = Math.round((this.frameCount * 1000) / (currentTime - this.lastTime));
                    this.fpsEl.textContent = this.fps;
                    this.frameCount = 0;
                    this.lastTime = currentTime;
                }
                
                // Perform detection
                const detections = await faceapi
                    .detectAllFaces(this.video, this.detectionOptions)
                    .withFaceLandmarks(true)
                    .withAgeAndGender();
                
                // Clear canvas
                this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
                
                if (detections && detections.length > 0) {
                    this.drawDetections(detections);
                    this.updateResults(detections);
                    this.updateStatus(`${detections.length} face(s) detected`, 'success');
                } else {
                    this.updateResults([]);
                    this.updateStatus('Looking for faces...', 'warning');
                }
                
            } catch (error) {
                console.error('Detection error:', error);
                this.updateStatus('Detection error occurred', 'error');
            }
            
            // Continue detection loop
            if (this.isDetecting) {
                setTimeout(() => {
                    requestAnimationFrame(detect);
                }, 100);
            }
        };
        
        // Start detection
        requestAnimationFrame(detect);
        this.updateStatus('Detecting faces...', 'info');
    }
    
    drawDetections(detections) {
        detections.forEach((detection, index) => {
            const box = detection.detection.box;
            
            // Draw bounding box
            this.ctx.strokeStyle = '#32a0ad';
            this.ctx.lineWidth = 3;
            this.ctx.strokeRect(box.x, box.y, box.width, box.height);
            
            // Prepare labels
            const age = Math.round(detection.age);
            const gender = detection.gender;
            const genderProb = Math.round(detection.genderProbability * 100);
            const label = `${age}y, ${gender} (${genderProb}%)`;
            
            // Draw label background
            this.ctx.fillStyle = 'rgba(50, 160, 173, 0.9)';
            this.ctx.font = '14px system-ui, -apple-system, sans-serif';
            const textMetrics = this.ctx.measureText(label);
            const textWidth = textMetrics.width + 12;
            const textHeight = 24;
            
            this.ctx.fillRect(
                box.x,
                box.y - textHeight - 5,
                textWidth,
                textHeight
            );
            
            // Draw label text
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillText(label, box.x + 6, box.y - 10);
            
            // Draw face number
            this.ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
            this.ctx.font = 'bold 16px system-ui, -apple-system, sans-serif';
            this.ctx.fillText(`${index + 1}`, box.x + 8, box.y + 20);
        });
    }
    
    updateResults(detections) {
        if (!detections || detections.length === 0) {
            this.resultsEl.innerHTML = `
                <div class="no-results">
                    <p>No face detected</p>
                    <small>Position your face in front of the camera</small>
                </div>
            `;
            return;
        }
        
        const resultsHtml = detections.map((detection, index) => {
            const age = Math.round(detection.age);
            const gender = detection.gender;
            const genderProb = Math.round(detection.genderProbability * 100);
            const confidence = Math.round(detection.detection.score * 100);
            const genderClass = gender === 'male' ? 'gender-male' : 'gender-female';
            
            return `
                <div class="face-result">
                    <div class="face-header">
                        <span class="face-number">Face ${index + 1}</span>
                        <span class="confidence">${confidence}% confidence</span>
                    </div>
                    <div class="face-details">
                        <div class="detail-item">
                            <span class="detail-label">Age</span>
                            <span class="detail-value age-value">${age} years</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Gender</span>
                            <span class="detail-value ${genderClass}">${gender} (${genderProb}%)</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
        
        this.resultsEl.innerHTML = resultsHtml;
    }
    
    stopDetection() {
        console.log('Stopping detection...');
        this.isDetecting = false;
        
        if (this.detectionLoop) {
            cancelAnimationFrame(this.detectionLoop);
            this.detectionLoop = null;
        }
        
        // Stop camera
        if (this.video.srcObject) {
            const tracks = this.video.srcObject.getTracks();
            tracks.forEach(track => {
                track.stop();
                console.log('Stopped track:', track);
            });
            this.video.srcObject = null;
        }
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Reset UI
        this.updateStatus('Stopped', 'info');
        this.fpsEl.textContent = '0';
        this.updateResults([]);
        this.showStoppedState();
    }
    
    showLoadingState() {
        this.startBtn.querySelector('.btn-text').textContent = 'Loading...';
        this.startBtn.querySelector('.loading-spinner').classList.remove('hidden');
        this.startBtn.disabled = true;
        this.loadingModal.classList.remove('hidden');
    }
    
    hideLoadingState() {
        this.startBtn.querySelector('.btn-text').textContent = 'Start Camera';
        this.startBtn.querySelector('.loading-spinner').classList.add('hidden');
        this.startBtn.disabled = false;
        this.loadingModal.classList.add('hidden');
    }
    
    showDetectingState() {
        this.startBtn.classList.add('hidden');
        this.stopBtn.classList.remove('hidden');
        this.updateStatus('Camera active', 'success');
    }
    
    showStoppedState() {
        this.stopBtn.classList.add('hidden');
        this.startBtn.classList.remove('hidden');
        this.startBtn.disabled = false;
    }
    
    updateLoadingStatus(message, progress) {
        this.loadingStatus.textContent = message;
        this.progressFill.style.width = `${progress}%`;
    }
    
    updateStatus(message, type) {
        this.statusEl.textContent = message;
        this.statusEl.className = `status status--${type}`;
    }
    
    showError(message) {
        console.error('Showing error:', message);
        document.getElementById('errorMessage').textContent = message;
        this.errorModal.classList.remove('hidden');
        this.showStoppedState();
    }
    
    hideModal(modal) {
        modal.classList.add('hidden');
    }
    
    getErrorMessage(error) {
        return error.message || 'An unexpected error occurred. Please refresh the page and try again.';
    }
}

// Wait for both DOM and face-api.js to be ready
async function initializeApp() {
    try {
        console.log('Initializing app...');
        
        // Wait for face-api.js to be available
        let attempts = 0;
        const maxAttempts = 50;
        
        while (!window.faceapi && attempts < maxAttempts) {
            console.log('Waiting for face-api.js...', attempts);
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }
        
        if (!window.faceapi) {
            throw new Error('Face-api.js library failed to load. Please refresh the page and try again.');
        }
        
        console.log('Face-api.js loaded:', !!window.faceapi);
        
        // Check browser support
        const errors = [];
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            errors.push('Camera access is not supported');
        }
        if (!HTMLCanvasElement.prototype.getContext) {
            errors.push('Canvas is not supported');
        }
        
        if (errors.length > 0) {
            throw new Error(`Browser compatibility issues:\n${errors.join('\n')}\n\nPlease use a modern browser.`);
        }
        
        // Initialize the app
        window.ageGenderApp = new AgeGenderDetection();
        console.log('App initialized successfully');
        
    } catch (error) {
        console.error('App initialization failed:', error);
        document.getElementById('errorMessage').textContent = error.message;
        document.getElementById('errorModal').classList.remove('hidden');
    }
}

// Start when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// Handle visibility changes
document.addEventListener('visibilitychange', () => {
    const app = window.ageGenderApp;
    if (app && document.hidden && app.isDetecting) {
        console.log('Page hidden, pausing detection');
        app.isDetecting = false;
    }
});